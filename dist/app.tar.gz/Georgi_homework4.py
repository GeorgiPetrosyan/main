# 1

# for i in range(350, 678):
#     if str(i)[-1] == str(7):
#         print(i)

# 2

# for i in range(0, 100):
#     if i % 2 == 0 and i % 3 == 0:
#         print(i)

# 3

# for i in range(0, 100):
#     if i % 5 == 0 and i % 3 == 0:
#         print(f"FizzBuzz and number is {i}")
#     elif i % 5 == 0:
#         print(f"Buzz and number is {i}")
#     elif i % 3 == 0:
#         print(f"Fizz and number is {i}")

# 4

# some_string = "Monty"
# new_string = ""
#
# for i in some_string:
#     new_string += i*2
#
# print(new_string)

# 5

# some_string = input("Please type your text: ")
# new_string = ""
#
# for i in range(len(some_string)-1, -1, -1):
#     new_string += some_string[i]
#
# print(new_string)

