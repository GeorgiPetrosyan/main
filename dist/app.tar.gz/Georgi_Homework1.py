# 1
#
# r = 12
# pi = 3.14
#
# s = pi * r * r
#
# '''Կամ էլ կարող ենք պի-ն իմպորտ անել)'''
# print(s)

# 2

# a = 418
# b = 16
# c = a % b
#
# print(c)

# 3

# n = 534
#
# first = n // 100
# second = n - 100 * first
# third = second // 10
# fourth = second - 10 * third
#
# print(first)
# print(third)
# print(fourth)

# 4

# new_string = "Hello World"
#
# print(new_string.replace("World", "ACA"))
# print(new_string.upper())
# print(new_string.replace("Hello", "New").upper())
# print(new_string.split())
# print(new_string.startswith("He"))
# print(new_string.endswith("rld"))
# print(new_string.count("H"))



