import logging
from aiogram import Bot, Dispatcher, types
from aiogram.types import WebAppInfo, Message
from aiogram.filters import Command
from aiogram.dispatcher.router import Router
from aiogram.fsm.storage.memory import MemoryStorage

logging.basicConfig(level=logging.INFO)

# Replace 'YOUR_BOT_TOKEN' with your actual bot token
BOT_TOKEN = "7051998833:AAES-n7e_0VFGkc3YmsIB_B3pGtlPVXW6RI"

# Initialize bot and dispatcher
bot = Bot(token=BOT_TOKEN)
storage = MemoryStorage()
dp = Dispatcher(storage=storage)

# Initialize router
router = Router()


@router.message(Command("start"))
async def send_welcome(message: Message):
    # Create a button with a web app link
    web_app_button = types.InlineKeyboardButton(
        text="Open Web App",
        web_app=WebAppInfo(url='https://aefe-46-71-240-89.ngrok-free.app')  # Replace with your desired URL
    )

    # Create a keyboard markup and add the button
    keyboard_markup = types.InlineKeyboardMarkup(inline_keyboard=[[web_app_button]])

    # Send the message with the button
    await message.answer("Welcome! Click the button below to open the web app.", reply_markup=keyboard_markup)


# Register router
dp.include_router(router)


# Main function to start the bot
async def main():
    await dp.start_polling(bot, skip_updates=True)


if __name__ == '__main__':
    import asyncio

    asyncio.run(main())
