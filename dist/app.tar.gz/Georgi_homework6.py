import mysql.connector

# Establish connection to MySQL server
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="----",
    database="employees"
)
cursor = conn.cursor()

# MySQL research code
cursor.execute('''
SELECT * FROM employees
WHERE birth_date >= '1960-01-01' AND 
first_name LIKE "B%" AND 
LENGTH(last_name) <= 4 AND 
hire_date > '1992-05-04'
''')
rows = cursor.fetchall()

# Loading info into file
with open("employees.txt", "x") as new_file:
    for item in rows:
        new_file.write(str(f"{item}\n"))

cursor.close()
conn.close()
