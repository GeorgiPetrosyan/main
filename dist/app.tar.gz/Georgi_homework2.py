# 1
#
# name = input("Please type your name: ")
# surname = input("Please type your surname: ")
#
# print(name[::-1])
# print(surname[::-1])

# 2
#
# digit = int(input("Please type a number: "))
#
# print((digit ** 2) * -1)

# 3

# str_2 = ("Benjamin Franklin had one of the greatest scientific minds of his time. "
#          "He was interested in many areas of science, made many discoveries, "
#          "and invented many things, including bifocal glasses. In the mid-1700s, "
#          "he became interested in electricity.")
#
# print(str_2[9:17])
# print(str_2[-12:-1])

# 4

# poem = "All that is gold does not glitter, Not all those who wander are lost, The old that is strong does not wither, Deep roots are not reached by the frost."
# new_poem = poem.split(", ")
#
# print(new_poem[0] + "\n\t" + new_poem[1] + "\n\t\t" + new_poem[2] + "\n\t\t\t" + new_poem[3])


