import flet as ft
from telegram import Update, Bot
from telegram.ext import Application, Updater, CommandHandler, MessageHandler, filters, CallbackContext

# Telegram bot token
TELEGRAM_BOT_TOKEN = "7051998833:AAES-n7e_0VFGkc3YmsIB_B3pGtlPVXW6RI"


# Function to handle start command
def start(update: Update, context: CallbackContext):

    update.message.reply_text("Hello! Please use the /login command to log in.")


# Function to handle login command
def login(update: Update, context: CallbackContext):
    context.user_data['login'] = True
    update.message.reply_text("Please enter your username:")


# Function to handle text messages
def handle_message(update: Update, context: CallbackContext):
    if context.user_data.get('login'):
        context.user_data['username'] = update.message.text
        context.user_data['login'] = False
        update.message.reply_text("Please enter your password:")
        context.user_data['password_login'] = True
    elif context.user_data.get('password_login'):
        context.user_data['password'] = update.message.text
        update.message.reply_text(f"Logged in as {context.user_data['username']}!")
        context.user_data['password_login'] = False
    else:
        update.message.reply_text("Unknown command. Use /start to begin.")


# Setting up the Telegram bot
def setup_telegram_bot():
    updater = Updater(TELEGRAM_BOT_TOKEN, use_context=True)
    # updater = Updater(TELEGRAM_BOT_TOKEN, use_context=True)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(CommandHandler("login", login))
    dp.add_handler(MessageHandler(filters.text & ~filters.command, handle_message))

    updater.start_polling()
    updater.idle()


# Flet app
def main(page: ft.Page):
    page.title = "Telegram Bot Login"

    # Username input
    username_input = ft.TextField(label="Username", width=300)
    # Password input
    password_input = ft.TextField(label="Password", password=True, width=300)

    def login_click(e):
        username = username_input.value
        password = password_input.value
        page.dialog = ft.AlertDialog(
            title="Login Info",
            content=ft.Text(f"Username: {username}\nPassword: {password}"),
            actions=[ft.TextButton("OK", on_click=lambda e: page.dialog.close())]
        )
        page.dialog.show()

    login_button = ft.ElevatedButton(text="Login", on_click=login_click)

    page.add(
        ft.Column(
            [
                username_input,
                password_input,
                login_button
            ],
            alignment="center",
            horizontal_alignment="center",
            spacing=20,
        )
    )


if __name__ == "__main__":
    # Start the Flet app
    ft.app(target=main)
    # Start the Telegram bot
    setup_telegram_bot()
