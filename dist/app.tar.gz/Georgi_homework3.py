# 1

# name = input("Please type your name: ")
# surname = input("Please type your surname: ")
#
# print(f"Your reversed name and surname : {name[::-1]} {surname[::-1]}")

# 2

# film = input("Please type film name: ")
# symbol = ["!", "@", "#", "$", "%", "^", "&"]
#
# if film[0].isupper():
#     print("Great title!")
# elif film[0] in symbol or film[0].isdigit():
#     print("I doubt that this is a title.")
# else:
#     print("Titles start with capital letters...")

# 3

# age = int(input("Please type your age: "))
#
# if age >= 17:
#     print("Կարող եք քվեարկել!")
# else:
#     print(f"Կարող եք քվեարկել {17-age} տարի հետո!")

# 4

# some_string = input("Please type something: ")
#
# if some_string[0] == "a" or some_string[0] == "o":
#     print(some_string)
# else:
#     print(some_string[::-1])

# 5

# digit = int(input("Please type some digit for calculation: "))
# if digit % 5 == 0 and digit % 3 == 0:
#     print("FizzBuzz")
# elif digit % 5 == 0:
#     print("Buzz")
# elif digit % 3 == 0:
#     print("Fizz")
# else:
#     print(digit)

# 6

# first = int(input("Type number: "))
# second = int(input("One more time: "))
# third = int(input("And last time: "))
#
# summ = first + second + third
#
# if summ % 2 == 0:
#     print(summ ** 2)
# else:
#     print(summ)

# 7

# password = input("Please type your password: ")
#
# contains_digit = any(char.isdigit() for char in password)
# contains_alpha = any(char.isalpha() for char in password)
#
# if contains_alpha and contains_digit and 6 < len(password) < 12:
#     print("Good password!")
# else:
#     print("Change your password")
