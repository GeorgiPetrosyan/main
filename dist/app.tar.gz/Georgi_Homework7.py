import mysql.connector as mc
import numpy as np

# Establish connection to MySQL server
conn = mc.connect(
    host="localhost",
    user="root",
    password="----",
    database="employees"
)
cursor = conn.cursor()

# MySQl research code
cursor.execute("""
SELECT emp_no, salary FROM salaries
WHERE salary > 145000
""")

database_info = cursor.fetchall()

# Loading info into file
with open("new_employees.txt", "w") as new_file:
    for item in database_info:
        new_file.write((f"{item}\n"))

cursor.close()
conn.close()

# Reading file and creating numpy array
info = []

with open("new_employees.txt", "r") as file:
    for item in file:
        info.append(tuple(item.strip("()\n").split(", ")))

np_info = np.array(info, dtype="int32")

# Calculations with numpy array

salary = np_info[:, 1]  # ''' Selecting second column from matrix'''

print(f"Մեծագույնը -> {np.max(salary)}")
print(f"Փոքրագույնը -> {np.min(salary)}")
print(f"Գումարը -> {np.sum(salary)}")
print(f"Միջինը -> {np.average(salary)}")
print(f"Մատրիցի չափերը -> {np_info.shape}")
print(f"Զբաղեցրած հիշողությունը -> {np_info.nbytes}")

salary += 10000
